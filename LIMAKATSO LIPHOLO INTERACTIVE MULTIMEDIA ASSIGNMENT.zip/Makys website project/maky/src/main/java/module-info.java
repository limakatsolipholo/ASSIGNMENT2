module com.example.maky {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.maky to javafx.fxml;
    exports com.example.maky;
}