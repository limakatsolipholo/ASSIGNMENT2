package com.example.maky;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.util.Pair;

import java.io.File;

public class HelloApplication extends Application {

    private VBox leftBox;
    private VBox rightBox;

    private Label headerLabel;
    private Label textLabel;

    @Override
    public void start(Stage primaryStage) throws Exception {
        BorderPane root = new BorderPane();

        // Create the left box with buttons
        leftBox = new VBox(10);
        leftBox.setPadding(new Insets(10));
        leftBox.setAlignment(Pos.CENTER_LEFT);

        Button logoButton = new Button("Logo");
        logoButton.setOnAction(e -> selectLogo());

        Button headerButton = new Button("Header");
        headerButton.setOnAction(e -> selectHeader());

        Button colorButton = new Button("Background Color");
       colorButton.setOnAction(e -> selectBackgroundColor());

        Button textButton = new Button("Text");
        textButton.setOnAction(e -> selectText());

        Button imageButton = new Button("Image");
        imageButton.setOnAction(e -> selectImage());

        Button addButton = new Button("Add Button");
        addButton.setOnAction(e -> addButtons());

        leftBox.getChildren().addAll(
                logoButton, headerButton, colorButton,
                textButton, imageButton, addButton
        );

        // Create the right box with header and text
        rightBox = new VBox(10);
        rightBox.setPadding(new Insets(10));
        rightBox.setAlignment(Pos.TOP_CENTER);
        rightBox.setStyle("-fx-background-color: red");

        headerLabel = new Label();
        headerLabel.setFont(new Font("Arial", 24));

        textLabel = new Label();
        textLabel.setFont(new Font("Arial", 16));

        rightBox.getChildren().addAll(headerLabel, textLabel);

        // Add the boxes to the root pane
        root.setLeft(leftBox);
        root.setCenter(rightBox);

        Scene scene = new Scene(root, 800, 600);
        scene.setFill(Color.BLUE);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void selectLogo() {
        // Open a file chooser dialog to select an image
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Select Logo");
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.gif")
        );

        Image image = loadImage(fileChooser.showOpenDialog(leftBox.getScene().getWindow()));
        if (image != null) {
            ImageView logoView = new ImageView(image);
            logoView.setFitWidth(200);
            logoView.setPreserveRatio(true);

            updateRightBox();
        }
    }

    private void selectHeader() {
        // Open a dialog to enter a header and select a font
        Dialog<Pair<String, String>> dialog = new Dialog<>();
        dialog.setTitle("Header");

        // Create the header input fields
        TextField headerField = new TextField();
        headerField.setPromptText("Enter header text");

        ComboBox<String> fontBox = new ComboBox<>();
        fontBox.getItems().addAll("Arial", "Verdana", "Times New Roman", "Courier New");
        fontBox.setValue("Arial");

        VBox content = new VBox(10);
        content.getChildren().addAll(
                new Label("Header Text:"),
                headerField,
                new Label("Font:"),
                fontBox
        );
        dialog.getDialogPane().setContent(content);

        // Add OK and Cancel buttons
        ButtonType okButton = new ButtonType("OK", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(okButton, ButtonType.CANCEL);
        // Set the result converter
        dialog.setResultConverter(buttonType -> {
            if (buttonType == okButton) {
                return new Pair<>(headerField.getText(), fontBox.getValue());
            }
            return null;
        });

        // Show the dialog and update the right box with the selected header
        Pair<String, String> result = dialog.showAndWait().orElse(null);
        if (result != null) {
            headerLabel.setText(result.getKey());
            headerLabel.setFont(new Font(result.getValue(), 24));

            updateRightBox();
        }
    }

    private void selectBackgroundColor() {
        // Open a color chooser dialog to select a background color
        ColorPicker colorPicker = new ColorPicker();
        colorPicker.setOnAction(event -> {
            Color color = colorPicker.getValue();
            rightBox.setStyle("-fx-background-color: " + toHexString(color));
        });
    }
    private String toHexString(Color color) {
        return String.format("#%02X%02X%02X",
                (int) (color.getRed() * 255),
                (int) (color.getGreen() * 255),
                (int) (color.getBlue() * 255));
    }

    private void selectText() {
        // Open a dialog to enter text and select a color
        Dialog<Pair<String, Color>> dialog = new Dialog<>();
        dialog.setTitle("Text");

        // Create the text input fields
        TextField textField = new TextField();
        textField.setPromptText("Enter text");

        ColorPicker colorPicker = new ColorPicker();
        colorPicker.setValue(Color.BLACK);

        VBox content = new VBox(10);
        content.getChildren().addAll(
                new Label("Text:"),
                textField,
                new Label("Color:"),
                colorPicker
        );
        dialog.getDialogPane().setContent(content);

        // Add OK and Cancel buttons
        ButtonType okButton = new ButtonType("OK", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(okButton, ButtonType.CANCEL);

        // Set the result converter
        dialog.setResultConverter(buttonType -> {
            if (buttonType == okButton) {
                return new Pair<>(textField.getText(), colorPicker.getValue());
            }
            return null;
        });

        // Show the dialog and update the right box with the selected text
        Pair<String, Color> result = dialog.showAndWait().orElse(null);
        if (result != null) {
            textLabel.setText(result.getKey());
            textLabel.setTextFill(result.getValue());

            updateRightBox();
        }
    }

    private void selectImage() {
        // Open a file chooser dialog to select an image
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Select Image");
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.gif")
        );

        Image image = loadImage(fileChooser.showOpenDialog(leftBox.getScene().getWindow()));
        if (image != null) {
            ImageView imageView = new ImageView(image);
            imageView.setFitWidth(400);
            imageView.setPreserveRatio(true);

            rightBox.getChildren().add(imageView);
        }
    }


    private void addButtons() {
        // Add two buttons side by side to the right box
        Button button1 = new Button("Button 1");
        button1.setPrefWidth(200);

        Button button2 = new Button("Button 2");
        button2.setPrefWidth(200);

        HBox hbox = new HBox(10);
        hbox.setAlignment(Pos.CENTER);
        hbox.getChildren().addAll(button1, button2);

        rightBox.getChildren().add(hbox);
    }

    private Image loadImage(File file) {
        // Load an image from a file
        if (file != null) {
            return new Image(file.toURI().toString());
        }
        return null;
    }

    private void updateRightBox() {
        // Clear the right box and add the updated content
        rightBox.getChildren().clear();
        rightBox.getChildren().add(headerLabel);
        // Add the text label
        rightBox.getChildren().add(textLabel);
    }



    private VBox createLeftBox() {
        // Create the logo button
        Button logoButton = new Button("Logo");
        logoButton.setOnAction(event -> selectImage());

        // Create the header button
        Button headerButton = new Button("Header");
        headerButton.setOnAction(event -> selectHeader());

        // Create the color button
        Button colorButton = new Button("Color");
      //  colorButton.setOnAction(event -> selectBackgroundColor());

        // Create the text button
        Button textButton = new Button("Text");
        textButton.setOnAction(event -> selectText());

        // Create the image button
        Button imageButton = new Button("Image");
        imageButton.setOnAction(event -> selectImage());

        // Create the add buttons button
        Button addButton = new Button("Add Buttons");
        addButton.setOnAction(event -> addButtons());

        // Add the buttons to a vertical box
        VBox vbox = new VBox(10);
        vbox.getChildren().addAll(
                logoButton,
                headerButton,
                colorButton,
                textButton,
                imageButton,
                addButton
        );
        return vbox;
    }

    private VBox createRightBox() {
        // Create the header label
        Label headerLabel = new Label("Header");
        headerLabel.setFont(new Font("Arial", 24));

        // Create the text label
        Label textLabel = new Label("Text");
        textLabel.setTextFill(Color.BLACK);

        // Add the labels to a vertical box
        VBox vbox = new VBox(20);
        vbox.setAlignment(Pos.CENTER);
        vbox.getChildren().addAll(headerLabel, textLabel);
        return vbox;
    }

    public static void main(String[] args) {
        launch(args);
    }

}
